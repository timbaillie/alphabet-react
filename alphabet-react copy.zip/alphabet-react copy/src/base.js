import Rebase from 're-base';

const base = Rebase.createClass({
    apiKey: "AIzaSyB32y8wO5EvGfN5V-X77s0f2SUJ5prJPVQ",
    authDomain: "alphabet-react.firebaseapp.com",
    databaseURL: "https://alphabet-react.firebaseio.com"
});

export default base;