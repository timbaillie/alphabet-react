const sampleScores = [
  {
    name: 'tim',
    score: 100
  },
  {
    name: 'jim',
    score: 90
  },
  {
    name: 'tom',
    score: 80
  },
  {
    name: 'james',
    score: 60
  },
  {
    name: 'paul',
    score: 24
  },
  {
    name: 'angus',
    score: 80
  },
  {
    name: 'sarah',
    score: 28
  },
  {
    name: 'stewie',
    score: 12
  },
];

export default sampleScores;