export function randomScore() {
    // generate a score between zero and 100
    return Math.floor(Math.random() * 101);
}
