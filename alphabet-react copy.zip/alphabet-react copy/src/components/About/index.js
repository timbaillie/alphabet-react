import React from 'react';
import Header from '../Header'
import './About.css';

class About extends React.Component {
    render() {
        return (
            <section>
                <Header headline="About the alphabet race"/>
                <p>blah blah blah, all about the alphabet race.</p>
            </section>
        );
    }
}

export default About;
